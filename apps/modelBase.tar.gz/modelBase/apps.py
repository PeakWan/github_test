from django.apps import AppConfig


class ModelbaseConfig(AppConfig):
    name = 'modelBase'
